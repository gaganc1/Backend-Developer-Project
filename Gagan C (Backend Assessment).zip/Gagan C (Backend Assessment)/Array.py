def unique_values(arr):
    return list(set(arr))


input_array = [1, 2, 3, 4, 5, 3, 4, 5, 6, 7, 8, 9, 1, 2]
unique_array = unique_values(input_array)
print(unique_array)
